
import React from "react";
import { Outlet } from "react-router-dom";
import Header from "../../Header/Header";
import Cards from '../../Cards'

const Home = () => {

  return (
    <div className="home">


           


    </div>
  );
};

export default Home;
