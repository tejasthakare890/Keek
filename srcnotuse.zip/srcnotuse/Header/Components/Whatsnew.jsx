import React from 'react'

const Whatsnew = () => {
  return (
    <div>
        <img  width="25" height="25" src="https://img.icons8.com/ios/50/confetti.png" alt="confetti"/>
    </div>
  )
}

export default Whatsnew