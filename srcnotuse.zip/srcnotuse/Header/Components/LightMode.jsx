import React from 'react'
import light from  '../Images/mode.png'

const LightMode = () => {
  return (
    <div>
 <img className='mode' src={light}  />

    </div>
  )
}

export default LightMode