import React from 'react'

const AccountNotification = () => {
  return (
    <div>
        <img width="25" height="25" src="https://img.icons8.com/ios/50/appointment-reminders--v1.png" alt="appointment-reminders--v1"/>
    </div>
  )
}

export default AccountNotification;