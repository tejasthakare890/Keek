import React from 'react'

const HelpLogo = () => {
  return (
    <img width="30" height="30" src="https://img.icons8.com/material-rounded/24/help.png" alt="help"/>
  )
}

export default HelpLogo