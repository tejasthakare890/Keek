import React from 'react'
import './Testing.scss'
const Testing = () => {
  return (
    <div className='test'>Testing
    </div>
  )
}

export default Testing