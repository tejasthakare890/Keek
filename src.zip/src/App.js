import { Routes, Route } from "react-router-dom";
import Setss from "./settings/setting";
import SideBar from "./components/sideBar/SideBar";
import "./App.css";
import Header from "./Header/Header";
import Cards from "./Cards";

function App() {
  return (
    <div className="app">
     <div className="sidecontent">
     <SideBar />
     <Header/>

     <div className="rightcontent">
        <Routes>
          <Route path="/" element={<Cards />} />
          <Route path="/managecampaigns" element={<Setss />}></Route>
          <Route path="/reportgeneration" element={<Setss />}></Route>
          <Route path="/savedlists" element={<Setss />}></Route>
          <Route path="/findinfluencers" element={<Setss />}></Route>
          <Route path="/influencersbase" element={<Setss />}></Route>
          <Route path="/settings" element={<Setss />} />
          <Route path="/hireinfluencers" element={<Setss />} />
          <Route path="/livesupport" element={<Setss />} />
        </Routes>
      </div>
     </div>

      
    </div>
  );
}

export default App;
