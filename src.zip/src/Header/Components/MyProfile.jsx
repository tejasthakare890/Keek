import React from 'react'

const MyProfile = () => {
  return (
   
       <div>
         <img width="40" height="40" src="https://img.icons8.com/ios-filled/50/user-male-circle.png" alt="user-male-circle"/>
    
       </div>
  )
}

export default MyProfile