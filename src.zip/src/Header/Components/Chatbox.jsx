import React from 'react'

const Chatbox = () => {
  return (
    <div>
        <img width="25" height="25" src="https://img.icons8.com/ios-filled/50/chat.png" alt="chat"/>
    </div>
  )
}

export default Chatbox