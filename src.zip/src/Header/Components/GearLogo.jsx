import React from 'react'

const GearLogo = () => {
  return (
    <img width="30" height="30" src="https://img.icons8.com/ios/50/settings--v1.png" alt="settings--v1"/>
  )
}

export default GearLogo