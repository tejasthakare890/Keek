import React from 'react'

const MyAccountLogo = () => {
  return (
    <img width="30" height="30" src="https://img.icons8.com/material-rounded/24/edit-user-male.png" alt="edit-user-male"/>
  )
}

export default MyAccountLogo